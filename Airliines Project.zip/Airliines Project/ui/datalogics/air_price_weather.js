rows = [];

var csvUrl =
  "https://raw.githubusercontent.com/Alluri-tejesh/airlines/main/air_data.csv";
$.get(csvUrl, function (csvString) {
  var arrayData = $.csv.toArrays(
    csvString,
    { onParseValue: $.csv.hooks.castToScalar },
    (omitFirstRow = true)
  );
  weather_type_list = [];
  for (let i = 1; i < arrayData.length; i++) {
    weather_type_list.push(arrayData[i][0]);
  }

  weather_type_set = new Set(weather_type_list);
  console.log(weather_type_set);

  const options = weather_type_set;
  const form = document.querySelector("form");
  const dropdown = document.querySelector("#dropdown");


  options.forEach((option) => {
    const optionElement = document.createElement("option");
    optionElement.value = option;
    optionElement.text = option;
    dropdown.appendChild(optionElement);
  });



  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const input1 = document.querySelector("#dropdown").value;

    let sub_div = document.createElement("div");

    for (let i = 1; i < arrayData.length; i++) {
      if ( arrayData[i][0] == input1) {
        sub_div.setAttribute("class", "row");
        sub_div.innerHTML += `
          <div class="col-sm ty">
                <div class="card" style="width: 20rem;">
                <div class="card-body">
                <h5 class="card-title">${arrayData[i][2]}</h5>
                <br>
                <p class="card-text">To</p>
                <br>
                <h5 class="card-title">${arrayData[i][3]}</h5>
                </div>
                <ul class="list-group list-group-flush">
                <li class="list-group-item">Diatance : ${arrayData[i][4]} Miles</li>
                <li class="list-group-item">Ticket Cost : $ ${arrayData[i][5]}</li>
                <li class="list-group-item">Airlines Names : ${arrayData[i][6]}</li>
                </ul>
                <div class="card-body">
                <button type="button" class="btn btn-outline-primary ry">Book Flight</button>
                <a href="#" class="card-link">${arrayData[i][0]}(${arrayData[i][1]} &#x2103;)</a>
                </div>
                </div>
                </div>
                `;
      }
    }

    let resultDiv = document.getElementById("resultDiv");
    resultDiv.innerHTML = "";
    resultDiv.appendChild(sub_div);
});

});




