rows = [];

var csvUrl =
  "https://raw.githubusercontent.com/Alluri-tejesh/airlines/main/air_data_weatherbased.csv";
$.get(csvUrl, function (csvString) {
  var arrayData = $.csv.toArrays(
    csvString,
    { onParseValue: $.csv.hooks.castToScalar },
    (omitFirstRow = true)
  );
  user_place_list = [];
  user_place_list1 = [];
  for (let i = 1; i < arrayData.length; i++) {
    user_place_list.push(arrayData[i][2]);
    user_place_list1.push(arrayData[i][3]);
  }

  user_place_list_set = new Set(user_place_list);
  user_place_list_set1 = new Set(user_place_list1);

  const form = document.querySelector("form");

  const options = user_place_list_set;

  const dropdown = document.querySelector("#dropdown");

  options.forEach((option) => {
    const optionElement = document.createElement("option");
    optionElement.value = option;
    optionElement.text = option;
    dropdown.appendChild(optionElement);
  });

  const options1 = user_place_list_set1;

  const dropdown1 = document.querySelector("#dropdown1");

  options1.forEach((options) => {
    const optionElement1 = document.createElement("option");
    optionElement1.value = options;
    optionElement1.text = options;
    dropdown1.appendChild(optionElement1);
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const input1 = document.querySelector("#dropdown").value;
    const input2 = document.querySelector("#dropdown1").value;
    const input3 = document.querySelector("#date").value;


    let sub_div = document.createElement("div");

    for (let i = 1; i < arrayData.length; i++) {
      if (arrayData[i][2] == input1 || arrayData[i][3]==input2) {
        console.log(arrayData[i][3])
       
        sub_div.setAttribute("class", "row");
        sub_div.innerHTML += `
          <div class="col-sm ty">
                <div class="card" style="width: 20rem;">
                <div class="card-body">
                <h5 class="card-title">${arrayData[i][2]}</h5>
                <br>
                <p class="card-text">To</p>
                <br>
                <h5 class="card-title">${arrayData[i][3]}</h5>
                </div>
                <ul class="list-group list-group-flush">
                <li class="list-group-item">Date : ${input3}</li>
                <li class="list-group-item">Diatance : ${
                  arrayData[i][4]
                } Miles</li>
                <li class="list-group-item">Ticket Cost : $ ${Math.round(
                  arrayData[i][5] +
                    Math.floor(Math.random() * input3.split("-")[2])
                )}</li>
                <li class="list-group-item">Airlines Names : ${
                  arrayData[i][6]
                }</li>
                </ul>
                <div class="card-body">
                <button type="button" class="btn btn-outline-primary ry">Book Flight</button>
                </div>
                </div>
                </div>
                `;
      }
     
    }

    let resultDiv = document.getElementById("resultDiv");
    resultDiv.innerHTML = "";
    resultDiv.appendChild(sub_div);
  });
});
