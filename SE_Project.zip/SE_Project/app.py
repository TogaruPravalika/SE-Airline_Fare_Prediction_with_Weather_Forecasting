import os
import csv
import requests
from datetime import datetime
from flask import Flask, render_template, request

app = Flask(__name__)

# Load predictions
with open('predictions.csv', 'r') as f:
    reader = csv.reader(f)
    next(reader)  # Skip header
    predictions_data = [row for row in reader]

# Replace with your own OpenWeatherMap API key
OPENWEATHERMAP_API_KEY = '23b44ac70007ab25baf7859a5453abf0'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_price', methods=['POST'])
def get_price():
    source = request.form['source']
    destination = request.form['destination']
    date = request.form['date']
    
    # Find the matching prediction
    price = None
    for row in predictions_data:
        if row[0] == source and row[1] == destination and row[2] == date:
            price = float(row[3])
            break

    if price is None:
        return {'error': 'No prediction available for the given source, destination, and date.'}

    # Get weather information for destination on the date
    timestamp = int(datetime.strptime(date, "%Y-%m-%d").timestamp())
    url = f'http://api.openweathermap.org/data/2.5/forecast?q={destination}&appid={OPENWEATHERMAP_API_KEY}&units=metric'
    response = requests.get(url)
    weather_data = response.json()

    # Find the weather data closest to the input date
    weather = None
    for item in weather_data['list']:
        if item['dt'] >= timestamp:
            weather = {
                'description': item['weather'][0]['description'],
                'temperature': item['main']['temp'],
                'humidity': item['main']['humidity'],
            }
            break

    if weather is None:
        return {'error': 'No weather data available for the given destination and date.'}

    return {'price': price, 'weather': weather}

if __name__ == '__main__':
    app.run(debug=True)
